"""桌面常驻元素方块：GTK3 窗口 + Cairo 绘制（与参考图一致的元素卡片）。"""
from __future__ import annotations

import gi

gi.require_version("Gtk", "3.0")
from gi.repository import Gdk, Gtk, Pango, PangoCairo  # noqa: E402

from . import platform_window  # noqa: E402
from .assets import hex_to_rgb  # noqa: E402

BASE = 132.0  # 设计基准尺寸，所有坐标按此比例缩放


def _text(cr, text: str, font: str, size: float, x: float, y: float,
          color, align: str = "left", max_width: float | None = None) -> None:
    """用 Pango 排版（自动字体回退，中文/扩展汉字交给 fontconfig）。"""
    layout = PangoCairo.create_layout(cr)
    desc = Pango.FontDescription(f"{font} {size}")
    layout.set_font_description(desc)
    layout.set_text(text, -1)
    width = layout.get_extents()[1].width / Pango.SCALE
    if max_width and width > max_width and width > 0:
        smaller = max(8.0, size * max_width / width)
        layout.set_font_description(Pango.FontDescription(f"{font} {smaller}"))
        width = layout.get_extents()[1].width / Pango.SCALE
    if align == "center":
        x -= width / 2
    elif align == "right":
        x -= width
    cr.set_source_rgb(*color)
    cr.move_to(x, y)
    PangoCairo.show_layout(cr, layout)


class BlockWindow(Gtk.Window):
    def __init__(self, state) -> None:
        super().__init__(type=Gtk.WindowType.TOPLEVEL)
        self.state = state
        self.set_title("Element Blocks Desktop")
        self.set_role("element-blocks-widget")

        self._area = Gtk.DrawingArea()
        self._area.connect("draw", self._on_draw)
        self.add(self._area)

        platform_window.apply_window_flags(self, state.cfg)
        state.on("element", lambda _e: self._area.queue_draw())
        state.on("settings", self._on_settings)

        self.connect("realize", self._on_realize)
        self.show_all()

    def _on_settings(self) -> None:
        platform_window.apply_window_flags(self, self.state.cfg)
        platform_window.place(self, self.state.cfg)
        platform_window.apply_click_through(self, self.state.cfg.click_through)
        self._area.queue_draw()

    def _on_realize(self, _window) -> None:
        platform_window.place(self, self.state.cfg)
        platform_window.apply_click_through(self, self.state.cfg.click_through)
        screen = Gdk.Screen.get_default()
        if screen:
            platform_window.on_screen_changed(screen, self._on_settings)

    def _on_draw(self, _area, cr) -> bool:
        tile = self.state.assets.theme["tile"]
        w = self._area.get_allocated_width()
        h = self._area.get_allocated_height()
        k = min(w, h) / BASE
        cr.save()
        cr.scale(k, k)

        cr.set_source_rgb(*hex_to_rgb(tile["background"]))
        cr.rectangle(0, 0, BASE, BASE)
        cr.fill()
        cr.set_source_rgb(*hex_to_rgb(tile["border"]))
        cr.set_line_width(max(1.0, tile["borderWidth"]))
        cr.rectangle(0.5, 0.5, BASE - 1, BASE - 1)
        cr.stroke()

        fg = hex_to_rgb(tile["foreground"])
        accent = hex_to_rgb(tile["accent"])
        e = self.state.current

        if e is None:
            _text(cr, "--", "Sans", tile["fontNumber"], 9, 7, fg)
            _text(cr, "—", "Serif", 40, BASE / 2, 34, fg, "center")
            _text(cr, "未启用任何元素", "Sans", 12, BASE / 2, 96, fg, "center", 118)
            _text(cr, "请在设置中启用", "Sans", 12, BASE / 2, 113, fg, "center", 118)
            cr.restore()
            return False

        num_color = accent if e.radioactive else fg
        _text(cr, str(e.number), "Sans", tile["fontNumber"], 9, 7, num_color)
        _text(cr, e.symbol, "Sans Bold", tile["fontSymbol"], 123, 7, num_color, "right")
        _text(cr, e.name_zh, "Serif", tile["fontNameZh"], BASE / 2, 30, fg, "center", 118)
        _text(cr, e.name_en, "Sans", tile["fontNameEn"], BASE / 2, 95, fg, "center", 116)
        _text(cr, e.mass, "Sans Bold", tile["fontMass"], BASE / 2, 113, fg, "center")

        cr.restore()
        return False
