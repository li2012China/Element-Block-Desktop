"""X11 / Wayland 差异处理：常驻窗口的层级、任务栏隐藏、锚点定位与点击穿透。

X11   : GDK_WINDOW_TYPE_HINT_DESKTOP + KEEP_BELOW + SKIP_TASKBAR/PAGER +
        gtk_window_move 绝对定位 + 空 input shape（点击穿透）——全部可用。
Wayland: 协议不允许客户端指定绝对坐标，也不允许 DESKTOP 类型窗口；
        set_type_hint / move / input_shape 会被合成器忽略。
        因此 Wayland 下退化为"无边框 + 不抢焦点 + 保持置底"的普通窗口，
        位置由合成器记住。wlroots 合成器可改用 gtk-layer-shell 的
        LayerSurface（LAYER_BACKGROUND）获得与 X11 等价的效果，见 docs/01。
"""
from __future__ import annotations

import os

import cairo
from gi.repository import Gdk, Gtk


def is_wayland() -> bool:
    display = Gdk.Display.get_default()
    cls = type(display).__name__.lower() if display else ""
    return ("wayland" in cls
            or os.environ.get("XDG_SESSION_TYPE", "").lower() == "wayland"
            or bool(os.environ.get("WAYLAND_DISPLAY")))


def apply_window_flags(window: Gtk.Window, cfg) -> None:
    window.set_decorated(False)
    window.set_resizable(False)
    window.set_skip_taskbar_hint(True)      # 任务栏不出现图标
    window.set_skip_pager_hint(True)        # 不在工作区切换器中出现
    window.set_keep_below(True)             # 位于普通窗口之下
    window.set_accept_focus(False)          # 不抢焦点
    window.set_focus_on_map(False)
    window.stick()                          # 所有虚拟桌面都显示
    window.set_type_hint(Gdk.WindowTypeHint.DESKTOP)  # X11: _NET_WM_WINDOW_TYPE_DESKTOP
    size = cfg.block_size
    window.set_default_size(size, size)
    window.resize(size, size)


def workarea(cfg) -> tuple[int, int, int, int]:
    """返回 (x, y, width, height)，使用工作区（已扣除 dock / 面板）。"""
    screen = Gdk.Screen.get_default()
    count = screen.get_n_monitors() if screen else 0
    if not count:
        if screen:
            return 0, 0, screen.get_width(), screen.get_height()
        return 0, 0, 1920, 1080
    idx = min(max(0, cfg.position.monitor_index), count - 1)
    r = screen.get_monitor_workarea(idx)
    return r.x, r.y, r.width, r.height


def place(window: Gtk.Window, cfg) -> tuple[int, int]:
    x0, y0, w0, h0 = workarea(cfg)
    size = cfg.block_size
    if cfg.position.anchor == "Custom":
        x, y = cfg.position.offset_x, cfg.position.offset_y
    else:
        right = "Right" in cfg.position.anchor
        bottom = "Bottom" in cfg.position.anchor
        x = x0 + w0 - size - cfg.position.offset_x if right else x0 + cfg.position.offset_x
        y = y0 + h0 - size - cfg.position.offset_y if bottom else y0 + cfg.position.offset_y
    x = max(x0, min(x, x0 + w0 - size))
    y = max(y0, min(y, y0 + h0 - size))
    if not is_wayland():
        window.move(x, y)   # Wayland 会忽略；由合成器记住上次位置
    return x, y


def apply_click_through(window: Gtk.Window, enabled: bool) -> bool:
    """X11 用空 input shape 让鼠标事件直接落到桌面；Wayland 不支持，返回 False。"""
    gdk = window.get_window()
    if gdk is None or is_wayland():
        return False
    try:
        if enabled:
            gdk.input_shape_combine_region(cairo.Region(), 0, 0)
        else:
            w, h = gdk.get_width(), gdk.get_height()
            gdk.input_shape_combine_region(
                cairo.Region(cairo.RectangleInt(0, 0, w, h)), 0, 0)
        return True
    except (AttributeError, TypeError):
        return False


def on_screen_changed(screen, callback) -> None:
    """显示器插拔 / 分辨率变化后重新按工作区锚点定位。"""
    screen.connect("monitors-changed", lambda _s: callback())
    screen.connect("size-changed", lambda _s: callback())
