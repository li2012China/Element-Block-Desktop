"""桌面常驻元素方块：GTK3 窗口 + Cairo 绘制（与参考图一致的元素卡片）。

v1.0.0-3 布局修复：
  · 整张卡片先 clip 到 BASE×BASE 的矩形 —— 任何文字都不可能画到方块外；
  · 每行文字有自己的文本框：Pango 实测宽高 → 等比缩字号 → 仍超长则省略号，
    底部行按实测行高上移，杜绝 "238.0" / 长英文名被方块下边缘截断；
  · 窗口被 WM 拉成非正方形时把卡片居中，并按 min(宽,高) 等比缩放，
    字体、配色、层级、点击穿透等视觉与交互行为保持不变。
"""
from __future__ import annotations

import gi

gi.require_version("Gtk", "3.0")
from gi.repository import Gdk, Gtk, Pango, PangoCairo  # noqa: E402

from . import layout, platform_window  # noqa: E402
from .assets import hex_to_rgb  # noqa: E402

BASE = 132.0   # 设计基准尺寸，所有坐标按此比例缩放
PAD = 4.0      # 卡片内边距（基准坐标）
MIN_FONT = 5.0


def _set_font(pl, font: str, size: float) -> None:
    pl.set_font_description(Pango.FontDescription(f"{font} {size}"))


def _text(cr, text: str, font: str, size: float, x: float, y: float,
          color, align: str = "left", max_width: float | None = None,
          bottom: float | None = None) -> None:
    """在「卡片内的文本框」里绘制单行文字：自动字体回退 + 缩放 + 省略 + 裁剪。"""
    if not text:
        return
    box_w = min(float(max_width) if max_width else BASE - 2 * PAD,
                BASE - 2 * PAD)
    bottom = min(float(bottom) if bottom is not None else BASE - PAD, BASE - PAD)

    pl = PangoCairo.create_layout(cr)   # 中英文/扩展汉字交给 fontconfig 回退
    pl.set_text(text, -1)
    pl.set_single_paragraph_mode(True)  # 不折成多行，超长用省略号收尾
    _set_font(pl, font, size)
    _ink, logical = pl.get_extents()
    w = logical.width / Pango.SCALE
    h = logical.height / Pango.SCALE

    fitted = layout.fit_font_size(size, w, h, box_w, max(1.0, bottom - y))
    if fitted < size:
        _set_font(pl, font, fitted)
        _ink, logical = pl.get_extents()
        w = logical.width / Pango.SCALE
        h = logical.height / Pango.SCALE

    # 限定文本框宽度后交给 Pango 对齐；超长时自动省略，绝不会画到框外
    pl.set_width(int(box_w * Pango.SCALE))
    pl.set_ellipsize(Pango.EllipsizeMode.END)
    pl.set_alignment(Pango.Alignment.CENTER if align == "center" else
                     Pango.Alignment.RIGHT if align == "right" else
                     Pango.Alignment.LEFT)
    left = layout.text_box_left(x, align, box_w, BASE, PAD)
    top = max(PAD, min(y, bottom - h))

    cr.set_source_rgb(*color)
    cr.move_to(left, top)
    PangoCairo.show_layout(cr, pl)


class BlockWindow(Gtk.Window):
    def __init__(self, state) -> None:
        super().__init__(type=Gtk.WindowType.TOPLEVEL)
        self.state = state
        self.set_title("Element Blocks Desktop")
        self.set_role("element-blocks-widget")

        self._area = Gtk.DrawingArea()
        self._area.connect("draw", self._on_draw)
        self.add(self._area)

        platform_window.apply_window_flags(self, state.cfg)
        state.on("element", lambda _e: self._area.queue_draw())
        state.on("settings", self._on_settings)

        self.connect("realize", self._on_realize)
        self.connect("configure-event", self._on_configure)
        self.show_all()

    def _on_settings(self) -> None:
        platform_window.apply_window_flags(self, self.state.cfg)
        platform_window.place(self, self.state.cfg)
        platform_window.apply_click_through(self, self.state.cfg.click_through)
        self._area.queue_draw()

    def _on_realize(self, _window) -> None:
        platform_window.place(self, self.state.cfg)
        platform_window.apply_click_through(self, self.state.cfg.click_through)
        screen = Gdk.Screen.get_default()
        if screen:
            platform_window.on_screen_changed(screen, self._on_settings)

    def _on_configure(self, _window, _event) -> bool:
        # WM 有可能在 map 之后重新摆放 DESKTOP 窗口，发现越界就重新收敛
        platform_window.enforce_bounds(self, self.state.cfg)
        return False

    def _on_draw(self, _area, cr) -> bool:
        w = self._area.get_allocated_width()
        h = self._area.get_allocated_height()
        if w <= 0 or h <= 0:
            return False

        tile = self.state.assets.theme["tile"]
        k = min(w, h) / BASE
        cr.save()
        cr.scale(k, k)
        # 非正方形分配时让卡片居中，避免贴边后被屏幕裁掉
        cr.translate((w / k - BASE) / 2.0, (h / k - BASE) / 2.0)
        cr.save()
        cr.rectangle(0, 0, BASE, BASE)
        cr.clip()   # ★ 硬边界：所有绘制都限制在卡片矩形内

        cr.set_source_rgb(*hex_to_rgb(tile["background"]))
        cr.rectangle(0, 0, BASE, BASE)
        cr.fill()
        cr.set_source_rgb(*hex_to_rgb(tile["border"]))
        cr.set_line_width(max(1.0, tile["borderWidth"]))
        cr.rectangle(0.5, 0.5, BASE - 1, BASE - 1)
        cr.stroke()

        fg = hex_to_rgb(tile["foreground"])
        accent = hex_to_rgb(tile["accent"])
        e = self.state.current

        if e is None:
            _text(cr, "--", "Sans", tile["fontNumber"], 9, 7, fg,
                  max_width=40, bottom=30)
            _text(cr, "—", "Serif", 40, BASE / 2, 34, fg, "center", bottom=92)
            _text(cr, "未启用任何元素", "Sans", 12, BASE / 2, 95, fg,
                  "center", 118, 111)
            _text(cr, "请在设置中启用", "Sans", 12, BASE / 2, 112, fg,
                  "center", 118, BASE - PAD)
            cr.restore()
            cr.restore()
            return False

        num_color = accent if e.radioactive else fg
        _text(cr, str(e.number), "Sans", tile["fontNumber"], 9, 7,
              num_color, max_width=40, bottom=30)
        _text(cr, e.symbol, "Sans Bold", tile["fontSymbol"], 123, 7,
              num_color, "right", 40, 30)
        _text(cr, e.name_zh, "Serif", tile["fontNameZh"], BASE / 2, 30,
              fg, "center", 118, 92)
        _text(cr, e.name_en, "Sans", tile["fontNameEn"], BASE / 2, 94,
              fg, "center", 116, 110)
        _text(cr, e.mass, "Sans Bold", tile["fontMass"], BASE / 2, 110,
              fg, "center", 116, BASE - PAD)

        cr.restore()   # 解除 clip
        cr.restore()   # 解除 scale / translate
        return False
